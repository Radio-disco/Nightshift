// NIGHTSHIFT online server. Zero dependencies: run with `node server.js`
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,MAX=6,GUID='258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const server=http.createServer((req,res)=>{
  if(req.url==='/health'){res.end('ok');return}
  fs.readFile(path.join(__dirname,'public','index.html'),(e,d)=>{
    if(e){res.writeHead(500);res.end('index.html missing');return}
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(d)})});
const rooms=new Map();let counter=0;
function send(c,str){if(c.sock.destroyed)return;const p=Buffer.from(str),n=p.length;let h;
  if(n<126)h=Buffer.from([0x81,n]);else if(n<65536)h=Buffer.from([0x81,126,n>>8,n&255]);
  else{h=Buffer.alloc(10);h[0]=0x81;h[1]=127;h.writeBigUInt64BE(BigInt(n),2)}
  c.sock.write(Buffer.concat([h,p]))}
function ctrl(c,op,payload=Buffer.alloc(0)){if(!c.sock.destroyed)c.sock.write(Buffer.concat([Buffer.from([0x80|op,payload.length]),payload]))}
function handle(c,txt){let m;try{m=JSON.parse(txt)}catch(e){return}
  if(m.t==='join'&&!c.room){const code=String(m.room||'').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,12);
    if(!code){send(c,JSON.stringify({t:'err',msg:'bad room code'}));return c.sock.end()}
    let r=rooms.get(code);if(!r){r={clients:new Set(),dirty:false};rooms.set(code,r)}
    if(r.clients.size>=MAX){send(c,JSON.stringify({t:'err',msg:'room full'}));return c.sock.end()}
    c.id=String(++counter).padStart(8,'0');c.room=code;r.clients.add(c);r.dirty=true;
    send(c,JSON.stringify({t:'hi',id:c.id}))}
  else if(m.t==='p'&&c.room&&m.p&&typeof m.p==='object'){if(txt.length>12000)return;c.p=m.p;rooms.get(c.room).dirty=true}}
function parse(c){
  for(;;){const b=c.buf;if(b.length<2)return;const fin=b[0]&128,op=b[0]&15,masked=b[1]&128;let len=b[1]&127,off=2;
    if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);off=4}
    else if(len===127){if(b.length<10)return;len=Number(b.readBigUInt64BE(2));off=10}
    if(len>1e6){c.sock.destroy();return}
    const need=off+(masked?4:0)+len;if(b.length<need)return;
    let payload=Buffer.from(b.subarray(off+(masked?4:0),need));
    if(masked){const k=b.subarray(off,off+4);for(let i=0;i<payload.length;i++)payload[i]^=k[i&3]}
    c.buf=b.subarray(need);
    if(op===8){ctrl(c,8);c.sock.end();return}
    if(op===9){ctrl(c,10,payload);continue}
    if(op===10)continue;
    if(op===1||op===2){c.frag=[payload];c.fop=op}else if(op===0)c.frag.push(payload);
    if(fin){const full=Buffer.concat(c.frag);c.frag=[];if(c.fop===1)handle(c,full.toString('utf8'))}}}
function drop(c){if(!c.room)return;const r=rooms.get(c.room);if(!r)return;r.clients.delete(c);if(!r.clients.size)rooms.delete(c.room);else r.dirty=true;c.room=null}
server.on('upgrade',(req,sock)=>{
  const key=req.headers['sec-websocket-key'];
  if(!key||String(req.headers.upgrade).toLowerCase()!=='websocket'){sock.destroy();return}
  const acc=crypto.createHash('sha1').update(key+GUID).digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+acc+'\r\n\r\n');
  sock.setNoDelay(true);
  const c={sock,id:null,room:null,p:{},buf:Buffer.alloc(0),frag:[],fop:1};
  sock.on('data',d=>{c.buf=Buffer.concat([c.buf,d]);parse(c)});
  sock.on('close',()=>drop(c));sock.on('error',()=>sock.destroy())});
// broadcast room snapshots ~20 times per second
setInterval(()=>{for(const r of rooms.values()){if(!r.dirty)continue;r.dirty=false;
  const msg=JSON.stringify({t:'s',peers:[...r.clients].map(c=>({id:c.id,p:c.p}))});for(const c of r.clients)send(c,msg)}},50);
// keep idle connections alive on hosting platforms
setInterval(()=>{for(const r of rooms.values())for(const c of r.clients)ctrl(c,9)},25000);
server.listen(PORT,()=>console.log('NIGHTSHIFT server running on http://localhost:'+PORT));
module.exports=server;
