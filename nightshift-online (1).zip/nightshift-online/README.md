# NIGHTSHIFT: The Last Shift (online co-op)

A real game server plus the game page. No installs or dependencies, just Node.js 16 or newer.

## Play with friends

1. Install Node.js from https://nodejs.org if you don't have it.
2. In this folder run:  `node server.js`
3. Open http://localhost:3000 and choose Play Online, then Host new room.
4. Friends open the same address and choose Join room with your room code.

The server address field in the Play Online screen is filled in automatically when you open the game from the server.

### Same Wi-Fi or home network
Friends open `http://YOUR-COMPUTER-IP:3000` (for example http://192.168.1.20:3000). Find your IP with `ipconfig` (Windows) or `ifconfig` / `ip a` (Mac/Linux). Allow Node through your firewall if asked.

### Friends anywhere on the internet (quickest)
Run a free tunnel while the server is running, then share the link it prints:
- Cloudflare: `cloudflared tunnel --url http://localhost:3000`
- ngrok: `ngrok http 3000`

### Keep it online all the time
Deploy this folder to any Node host (Render, Railway, Fly.io and similar). Start command: `node server.js`. The host provides the PORT automatically. Share the site's address and everyone plays from it.

## Notes
- Up to 6 players per room, any number of rooms.
- The server only relays player positions and the host's game state, so the first player in a room runs the monsters. If they leave, the next player takes over.
- Health check address: `/health`.

## Put it online in about 5 minutes (Render, free)
1. Create a free account at https://github.com and make a new repository, then upload every file from this folder to it (drag and drop works on the repository page).
2. Create a free account at https://render.com, choose New, then Blueprint, and pick your repository. Render reads `render.yaml` and sets everything up.
3. When the deploy finishes you get a link like `https://nightshift-xxxx.onrender.com`. Send that link to your friends. Everyone opens it, chooses Play Online and uses the same room code.

The free plan sleeps after a while with no players, so the first visit can take about a minute to wake up. Railway, Fly.io and any host that runs Node or Docker also work.
